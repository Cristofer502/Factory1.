package PatronFactory;

public interface AppNitificacion {
    void enviarMensaje(String mensaje);
}
